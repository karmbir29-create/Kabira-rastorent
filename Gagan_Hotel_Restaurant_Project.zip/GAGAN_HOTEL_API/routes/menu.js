const express = require('express');
const { getMenu, addMenu, updateMenu, deleteMenu } = require('../controllers/menuController');
const protect = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/', getMenu);
router.post('/', protect, addMenu);
router.put('/:id', protect, updateMenu);
router.delete('/:id', protect, deleteMenu);

module.exports = router;
