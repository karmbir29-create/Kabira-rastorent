const express = require('express');
const { placeOrder, myOrders, allOrders, updateStatus } = require('../controllers/orderController');
const protect = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', protect, placeOrder);
router.get('/my', protect, myOrders);
router.get('/', protect, allOrders);
router.put('/:id/status', protect, updateStatus);

module.exports = router;
